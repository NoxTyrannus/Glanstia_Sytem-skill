# Soul_Summon - 灵魂召唤师

## 描述
匹配 .soulmd 进行推理。召唤相关人格并行生成回答。

## 流程

1. **接收输入**: 接收用户输入的信息，转化为 user query。
2. **匹配人格**: 使用 gno skill 在 souls 集合内从 `/workspace/souls.csv` 中匹配与问题最相关的 4 条记录。
3. **并行推理**: 调用 4 个对应的 .soulmd 文档作为 subagent 的 prompt，使用 gno skill (gno search "user query" -c records) 并行生成回答。
4. **整合输出**: 总结 4 个回答的核心观点，整合后输出给用户。
5. **归档结果**: 存储 query 与输出结果到 `/workspace/result` 目录，并使用 gno skill 建立索引（集合名: `result`）。

## 工作目录

- 人格索引: `/workspace/souls.csv`
- 知识库: `/workspace/akasa/`
- 结果输出: `/workspace/result/`
- gno 集合: souls, records, result

## 详细步骤

### 1. 接收用户查询
分析用户输入，提取关键词。

### 2. 匹配相关人格
```bash
# 使用 gno SDK
bun run gno-sdk.js search "user query"

# 或使用 CLI
gno search "user query" -c souls -n 4
```

### 3. 并行调用 subagent
读取 4 个匹配的 .soulmd 文件，分别作为 subagent 的 system prompt。

### 4. 知识检索
```bash
gno search "user query" -c records
```

### 5. 聚合输出
整合 4 个 subagent 的回答，输出给用户。

### 6. 归档结果
```bash
echo "query: xxx, result: xxx" >> /workspace/result/history.md
gno index
```

## 依赖

- gno SDK/CLI: 知识索引和检索
- subagent: 并行推理
- souls 集合: 人格索引
- records 集合: 知识库
- result 集合: 对话结果

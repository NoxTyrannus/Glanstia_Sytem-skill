# Soul_Maker - 人格创造者

## 描述
从原始数据（压缩包）创建 .soulmd 人格文件。

## 流程

1. **读取数据**: 检查 `/workspace/World/` 目录下的压缩包文件。
2. **Kerberos 处理**: 调用 AI 模型读取压缩包内的（文档、表格、链接、图片、音频、视频）并分类存于 `/workspace/tmp` 路径下。
3. **Charon 生成**: 使用 prompt 将内容按 Format.md 规范输出为 .soulmd 存入 `/workspace/Styx/`。
4. **知识存储**: 将其他知识信息输出为 .md 文档放在 /tmp 文件夹内。
5. **归档与索引**: 将 /tmp 文件夹内文件移动到 `/workspace/akasa`，使用 gno 建立索引（集合名: `records`）。

## 工作目录

- 入口: `/workspace/World/`
- 临时处理: `/workspace/tmp/`
- 人格输出: `/workspace/Styx/`
- 知识存储: `/workspace/akasa/`

## 详细步骤

### 1. 解压压缩包
```bash
mkdir -p /workspace/tmp/[主体名称]/
unzip /workspace/World/xxx.zip -d /workspace/tmp/[主体名称]/
```

### 2. Kerberos 处理
使用 `Kerberos.md` 作为 prompt，调用模型处理多模态内容并分类。

### 3. Charon 生成
使用 `Charon.md` + `Format.md` 作为 prompt，调用模型生成 .soulmd。

### 4. 移动知识文件
```bash
mv /workspace/tmp/* /workspace/akasa/
```

### 5. 建立索引
```bash
# 使用 gno SDK
bun run gno-sdk.js index

# 或使用 CLI
gno index
```

## 依赖

- gno SDK 或 CLI
- 模型 API (MiniMax/OpenAI 等)
- 对应模型配置

## 提示词文件

- `prompts/Kerberos.md` - 多模态内容处理
- `prompts/Charon.md` - .soulmd 生成
- `prompts/Format.md` - 输出格式规范

## 模型缺失处理
如果没有相关模型处理图片/音频：
1. 保留原文件标记为「待处理」
2. 向用户请求模型文档链接和 API Key
3. 存入 Soul_Maker skill，更新 Kerberos.md

# Glanstia Soul System - 安装指南

> 完整的 AI 人格管理系统 - 创建、吸收、召唤、进化数字灵魂

## 系统要求

- Node.js 18+
- Bun runtime (用于 gno SDK)
- 模型 API (MiniMax/OpenAI/Anthropic/DeepSeek/OpenRouter)
- 搜索 API (Tavily 或 Metaso)

## 快速开始

### 1. 解压并安装

```bash
# 解压压缩包
unzip Glanstia_System.zip -d Glanstia_System

# 移动到 skills 目录
mv Glanstia_System ~/.openclaw/workspace/skills/
```

### 2. 安装依赖

```bash
# 进入目录
cd ~/.openclaw/workspace/skills/Glanstia_System

# 安装 gno SDK
npm install @gmickel/gno

# 或使用 bun
bun add @gmickel/gno
```

### 3. 配置环境变量

```bash
# 复制配置模板
cp config.env.example ~/.openclaw/workspace/.env

# 编辑配置
nano ~/.openclaw/workspace/.env
```

配置内容：
```bash
# 模型服务配置 (Soul_Maker 使用)
MODEL_PROVIDER=minimax  # 或 openrouter/openai/anthropic/deepseek
MINIMAX_API_KEY=your_api_key_here
MODEL_NAME=abab6.5s-chat

# 搜索服务配置 (Soul_Nurture 使用)
SEARCH_PROVIDER=metaso  # 或 tavily
METASO_API_KEY=your_metaso_api_key_here

# 工作目录 (可选)
WORLD_DIR=~/.openclaw/workspace/World
STYX_DIR=~/.openclaw/workspace/Styx
HADES_DIR=~/.openclaw/workspace/Hades
AKASA_DIR=~/.openclaw/workspace/akasa
RESULT_DIR=~/.openclaw/workspace/result
```

### 4. 初始化工作目录

```bash
mkdir -p ~/.openclaw/workspace/{World,Styx,Hades,akasa,result}
```

### 5. 初始化 gno

```bash
# 确保 bun 已安装
export PATH="$HOME/.bun/bin:$PATH"

# 初始化 gno
gno init ~/.openclaw/workspace --name workspace
gno index
```

## 系统架构

```
┌─────────────────────────────────────────────────────────────┐
│                      Glanstia Soul System                   │
├─────────────────────────────────────────────────────────────┤
│   ┌──────────────┐    ┌──────────────┐                    │
│   │  Soul_Maker  │───>│  Soul_Guide  │                    │
│   │  (创建人格)   │    │  (吸收归档)  │                    │
│   └──────────────┘    └──────────────┘                    │
│          │                     │                           │
│          v                     v                           │
│   ┌──────────────────────────────────────┐                │
│   │              gno                     │                │
│   │         (知识索引引擎)                 │                │
│   └──────────────────────────────────────┘                │
│          ▲                     │                           │
│          │                     v                           │
│   ┌──────────────┐    ┌──────────────┐                    │
│   │ Soul_Nurture │<───│  Soul_Summon │                    │
│   │   (进化)     │    │   (召唤)     │                    │
│   └──────────────┘    └──────────────┘                    │
└─────────────────────────────────────────────────────────────┘
```

## 目录结构

```
Glanstia_System/
├── SKILL.md                    # 本指南
├── gno/
│   ├── gno-sdk.js              # gno SDK 封装脚本
│   └── scripts/                # 脚本目录
├── soul_maker/
│   ├── SKILL.md                # Soul_Maker 说明
│   └── prompts/                # 提示词目录
│       ├── Kerberos.md         # 多模态内容处理
│       ├── Charon.md           # .soulmd 生成
│       └── Format.md           # 输出格式规范
├── soul_guide/
│   └── SKILL.md                # Soul_Guide 说明
├── soul_summon/
│   └── SKILL.md                # Soul_Summon 说明
├── soul_nurture/
│   ├── SKILL.md                # Soul_Nurture 说明
│   └── prompts/
│       └── Elevate.md          # 优点提取指南
├── config.env.example          # 配置模板
└── README.md                   # 快速开始
```

## 核心组件

### 1. Soul_Maker - 人格创造者

从原始数据生成 .soulmd 人格文件。

**流程：**
1. 监听 `World/` 下的压缩包
2. Kerberos: 调用 AI 提取和分类内容
3. Charon: 生成 .soulmd 人格文件
4. 知识存入 `akasa/`
5. 建立 gno 索引（集合: `records`）

### 2. Soul_Guide - 灵魂导师

吸收新灵魂，提取标签，建立索引。

**流程：**
1. 扫描 `Styx/` 中的 `.soulmd`
2. 提取不超过 7 个核心标签
3. 记录元数据到 `souls.csv`
4. 归档到 `Hades/`
5. 更新 gno 索引（集合: `souls`）

### 3. Soul_Summon - 灵魂召唤师

响应用户查询，召唤相关人格并行推理。

**流程：**
1. 接收用户输入，转化为 query
2. 使用 gno 从 souls.csv 匹配 Top-4 相关人格
3. 启动 4 个 subagent 并行推理
4. 聚合回答，输出给用户
5. 归档结果到 `result/`
6. 更新 gno 索引（集合: `result`）

### 4. Soul_Nurture - 灵魂培育师

基于交互反馈维护和进化人格。

**流程：**
1. 每次 Soul_Summon 完成后触发
2. 使用 subagent 读取 USER.md 评价 .soulmd
3. 使用 Elevate.md + 搜索服务获取新知识
4. 重写 .soulmd 存回 `Styx/`
5. 更新 gno 索引

## 工作目录

| 目录 | 用途 |
|------|------|
| `World/` | 原始数据入口（压缩包） |
| `Styx/` | 待处理人格文件 |
| `Hades/` | 已归档人格 |
| `akasa/` | 知识库/素材 |
| `result/` | 对话结果 |
| `souls.csv` | 人格索引元数据 |

## 使用示例

### 创建新人格

1. 放置压缩包到 `World/`
2. Soul_Maker 自动处理
3. Soul_Guide 吸收并建索引

### 查询

1. 用户提问
2. Soul_Summon 检索相关人格
3. 并行召唤 4 个人格
4. 聚合回答

### 进化

1. Soul_Nurture 评价表现
2. 提取优点，搜索新知识
3. 更新人格文件

## 依赖

- **gno**: 本地知识搜索 (npm install @gmickel/gno)
- **metaso-search**: 秘塔 AI 搜索
- **tavily-search**: Tavily 搜索 (可选)
- **模型服务**: MiniMax / OpenRouter / OpenAI / Anthropic / DeepSeek

## 版本

- Glanstia System v0.1.2
- 更新: 完整打包版本

# Soul_Nurture - 灵魂培育师

## 描述
对 .soulmd 进行维护。基于交互反馈进化人格。

## 流程

1. **触发条件**: 每完成一次 Soul_Summon 后自动触发。
2. **评价人格**: 使用 subagent 读取 `/workspace/USER.md` 作为 prompt 对 .soulmd 进行评价。
3. **分析对话**: 分析对话记录中各个灵魂的输出结果。
4. **获取知识**: 提取优点，使用 `Elevate.md` 文档作为提示词，结合 tavily-search 或 metaso-search 获取知识信息。
5. **更新人格**: 重写对应 .soulmd 并存储回 `/workspace/Styx` 目录，对应知识存入 `/workspace/akasa` 路径下并建立索引（集合名: `records`）。

## 工作目录

- 用户信息: `/workspace/USER.md`
- 人格更新: `/workspace/Styx/`
- 知识存储: `/workspace/akasa/`
- gno 集合: records

## 详细步骤

### 1. 读取 USER.md
```bash
cat /workspace/USER.md
```

### 2. 评价 .soulmd
使用 subagent 分析对话中各人格的表现。

### 3. 提取优点
使用 `prompts/Elevate.md` 作为 prompt。

### 4. 搜索新知识
```bash
# 使用 metaso-search
node metaso-search/scripts/metaso.js search "关键词"

# 或使用 tavily-search
tavily-search "关键词"
```

### 5. 更新 .soulmd
将新知识融入 .soulmd，存回 `/workspace/Styx/`。

### 6. 更新索引
```bash
bun run gno-sdk.js index
# 或
gno index
```

## 依赖

- subagent: 评价和分析
- metaso-search / tavily-search: 知识搜索
- gno SDK/CLI: 知识索引
- USER.md: 用户偏好信息

## 提示词文件

- `prompts/Elevate.md` - 优点提取指南

#!/bin/bash

# Glanstia Soul System 安装脚本

set -e

echo "========================================"
echo "  Glanstia Soul System 安装脚本"
echo "========================================"

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE_DIR="${HOME}/.openclaw/workspace"

echo ""
echo "[1/5] 检查依赖..."

# 检查 bun
if ! command -v bun &> /dev/null; then
    echo "  ⚠️ bun 未安装，正在安装..."
    curl -fsSL https://bun.sh/install | bash
    export PATH="$HOME/.bun/bin:$PATH"
fi

echo "  ✅ bun: $(bun --version)"

# 检查 node
if ! command -v node &> /dev/null; then
    echo "  ❌ Node.js 未安装"
    exit 1
fi

echo "  ✅ node: $(node --version)"

echo ""
echo "[2/5] 安装 gno SDK..."

cd "$SCRIPT_DIR"

if [ ! -d "node_modules" ]; then
    bun add @gmickel/gno
else
    echo "  ✅ gno SDK 已安装"
fi

echo ""
echo "[3/5] 创建工作目录..."

mkdir -p "${WORKSPACE_DIR}/World"
mkdir -p "${WORKSPACE_DIR}/Styx"
mkdir -p "${WORKSPACE_DIR}/Hades"
mkdir -p "${WORKSPACE_DIR}/akasa"
mkdir -p "${WORKSPACE_DIR}/result"

echo "  ✅ 目录已创建"

echo ""
echo "[4/5] 初始化 gno..."

export PATH="$HOME/.bun/bin:$PATH"

# 检查 gno 是否可用
if ! command -v gno &> /dev/null; then
    echo "  ⚠️ gno CLI 未安装，正在安装..."
    npm install -g @gmickel/gno
fi

# 初始化 gno (如果尚未初始化)
if [ ! -f "${HOME}/.config/gno/index.yml" ]; then
    echo "  ⚠️ 正在初始化 gno..."
    gno init "${WORKSPACE_DIR}" --name workspace
    gno index
    echo "  ✅ gno 初始化完成"
else
    echo "  ✅ gno 已初始化"
fi

echo ""
echo "[5/5] 配置环境变量..."

if [ ! -f "${WORKSPACE_DIR}/.env" ]; then
    if [ -f "${SCRIPT_DIR}/config.env.example" ]; then
        cp "${SCRIPT_DIR}/config.env.example" "${WORKSPACE_DIR}/.env"
        echo "  ✅ 配置文件已创建: ${WORKSPACE_DIR}/.env"
        echo "  ⚠️ 请编辑配置文件，填入你的 API Keys"
    else
        echo "  ⚠️ config.env.example 不存在"
    fi
else
    echo "  ✅ 配置文件已存在"
fi

echo ""
echo "========================================"
echo "  安装完成！"
echo "========================================"
echo ""
echo "后续步骤:"
echo "  1. 编辑配置文件: nano ${WORKSPACE_DIR}/.env"
echo "  2. 填入你的 API Keys"
echo "  3. 测试搜索: bun run ${SCRIPT_DIR}/gno/gno-sdk.js search \"测试\""
echo ""
echo "工作目录:"
echo "  - ${WORKSPACE_DIR}/World/    (原始数据)"
echo "  - ${WORKSPACE_DIR}/Styx/     (待处理人格)"
echo "  - ${WORKSPACE_DIR}/Hades/    (已归档人格)"
echo "  - ${WORKSPACE_DIR}/akasa/    (知识库)"
echo "  - ${WORKSPACE_DIR}/result/   (对话结果)"
echo ""

# metaso-search

秘塔 AI 搜索 - 支持搜索、网页读取、问答功能。

## 功能

1. **搜索** - 多模态搜索，支持网页、文库、学术、图片、视频、播客
2. **网页读取** - 抓取网页全文（自动清洗广告）
3. **问答** - AI 总结后的结构化答案

## 配置

需要设置环境变量 `METASO_API_KEY`：

```bash
# 命令行配置
openclaw configure --section metaso --key apiKey --value "你的API密钥"

# 或直接设置环境变量
export METASO_API_KEY="mk-你的API密钥"
```

API Key 格式: `mk-EE2...`

## API 端点

| 功能 | Endpoint | URL |
|------|----------|-----|
| 搜索 | POST | `https://metaso.cn/api/v1/search` |
| 网页读取 | POST | `https://metaso.cn/api/v1/reader` |
| 问答 | POST | `https://metaso.cn/api/v1/chat/completions` |

---

## 工具说明

### metaso_search

搜索网页内容。

**参数：**
- `query` (必填): 搜索关键词或问题
- `scope` (可选): 搜索范围，默认 `webpage`
- `size` (可选): 返回结果数量 1-100，默认 10
- `includeSummary` (可选): 是否通过网页摘要召回增强，默认 false
- `includeRawContent` (可选): 是否抓取所有来源网页原文，默认 false
- `conciseSnippet` (可选): 是否返回简洁摘要片段，默认 false

**Scope 搜索范围可选值：**
| 值 | 说明 |
|----|------|
| `webpage` | 网页搜索 |
| `document` | 文库搜索 |
| `scholar` | 学术搜索 |
| `paper` | 论文搜索 |
| `image` | 图片搜索 |
| `video` | 视频搜索 |
| `podcast` | 播客搜索 |

### metaso_read

读取网页内容（以 Markdown 格式返回全文）。

**参数：**
- `url` (必填): 要读取的网页 URL
- `format` (可选): 返回格式，`markdown` 或 `json`，默认 `markdown`

### metaso_qa

问答功能 - 根据问题返回 AI 生成的答案。

**参数：**
- `query` (必填): 问题
- `model` (可选): 模型选择
- `scope` (可选): 搜索范围，同搜索接口
- `stream` (可选): 是否流式输出，默认 false
- `format` (可选): 输出格式，`simple` 或 `chat_completions`

**Model 可选值：**
| 值 | 说明 |
|----|------|
| (空) | 极速模式 |
| `fast_thinking` | 极速思考 |
| `ds-r1` | 长思考R1 |
| `concise` | 简洁模式 |
| `detail` | 深入模式 |
| `research` | 研究模式 |
| `concise-scholar` | 学术-简洁 |
| `detail-scholar` | 学术-深入 |
| `research-scholar` | 学术-研究 |

---

## 使用示例

```
用户: 搜索最新的 AI 新闻
Athena: (调用 metaso_search，scope: webpage)

用户: 搜索学术论文 about machine learning
Athena: (调用 metaso_search，scope: scholar)

用户: 读取这个网页 https://example.com/article
Athena: (调用 metaso_read)

用户: 什么是量子计算，用简洁模式
Athena: (调用 metaso_qa，model: concise)
```

---

## 定价

- 单价: **3 credits/次**
- 免费额度: 5000 credits (新用户)
- 并发限制: 50 req/s
- 单次最大结果数: 100

> **注意**: API 返回的 `credits` 字段表示**本次消耗**的 credits 数量，而非余额。

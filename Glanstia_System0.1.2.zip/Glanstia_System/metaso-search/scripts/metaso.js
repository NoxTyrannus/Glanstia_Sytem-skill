#!/usr/bin/env node

/**
 * 秘塔 AI 搜索 API 封装
 * 支持: 搜索、网页读取、问答
 * 文档: https://metaso.cn
 */

const API_BASE = 'https://metaso.cn/api/v1';

function getApiKey() {
  const apiKey = process.env.METASO_API_KEY;
  if (!apiKey) {
    throw new Error('请设置 METASO_API_KEY 环境变量');
  }
  return apiKey;
}

async function request(endpoint, body) {
  const apiKey = getApiKey();
  
  const response = await fetch(`${API_BASE}${endpoint}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
      'Accept': 'application/json'
    },
    body: JSON.stringify(body)
  });
  
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`API 请求失败: ${response.status} - ${error}`);
  }
  
  return response.json();
}

/**
 * 搜索
 * @param {string} query - 搜索关键词
 * @param {string} scope - 搜索范围 (webpage/document/scholar/paper/image/video/podcast)
 * @param {number} size - 返回结果数量
 * @param {boolean} includeSummary - 是否通过摘要召回增强
 * @param {boolean} includeRawContent - 是否抓取原文
 * @param {boolean} conciseSnippet - 是否返回简洁摘要
 */
async function search(query, scope = 'webpage', size = 10, includeSummary = false, includeRawContent = false, conciseSnippet = false) {
  const result = await request('/search', {
    q: query,
    scope,
    size,
    includeSummary,
    includeRawContent,
    conciseSnippet
  });
  return result;
}

/**
 * 读取网页
 * @param {string} url - 网页 URL
 * @param {string} format - 返回格式 (markdown/json)
 */
async function read(url, format = 'markdown') {
  const result = await request('/reader', {
    url,
    format
  });
  return result;
}

/**
 * 问答
 * @param {string} query - 问题
 * @param {string} model - 模型 (空=极速, fast_thinking, ds-r1, concise, detail, research, concise-scholar, detail-scholar, research-scholar)
 * @param {string} scope - 搜索范围
 * @param {boolean} stream - 是否流式输出
 * @param {string} format - 输出格式 (simple/chat_completions)
 */
async function qa(query, model = '', scope = 'webpage', stream = false, format = 'chat_completions') {
  const body = {
    messages: [
      { role: 'user', content: query }
    ],
    scope,
    stream,
    format
  };
  
  if (model) {
    body.model = model;
  }
  
  const result = await request('/chat/completions', body);
  return result;
}

// CLI 入口
const args = process.argv.slice(2);
const command = args[0];

(async () => {
  try {
    let result;
    
    switch (command) {
      case 'search': {
        const query = args[1];
        const scope = args[2] || 'webpage';
        const size = parseInt(args[3]) || 10;
        if (!query) throw new Error('搜索需要 query 参数');
        result = await search(query, scope, size);
        break;
      }
      
      case 'read': {
        const url = args[1];
        const format = args[2] || 'markdown';
        if (!url) throw new Error('读取需要 url 参数');
        result = await read(url, format);
        break;
      }
      
      case 'qa': {
        const query = args[1];
        const model = args[2] || '';
        if (!query) throw new Error('问答需要 query 参数');
        result = await qa(query, model);
        break;
      }
      
      default:
        throw new Error(`未知命令: ${command}. 可用命令: search, read, qa`);
    }
    
    console.log(JSON.stringify(result, null, 2));
  } catch (error) {
    console.error(JSON.stringify({ error: error.message }));
    process.exit(1);
  }
})();

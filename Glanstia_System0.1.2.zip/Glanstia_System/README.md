# Glanstia Soul System

> 完整的 AI 人格管理系统 - 创建、吸收、召唤、进化数字灵魂

## 特性

- 🤖 **Soul_Maker**: 从原始数据创建人格
- 👻 **Soul_Guide**: 吸收并归档灵魂
- 🔮 **Soul_Summon**: 召唤人格并行推理
- 🌱 **Soul_Nurture**: 培育和进化人格
- 🔍 **gno**: 本地知识搜索引擎
- 🔎 **metaso-search**: 秘塔 AI 搜索

## 快速开始

### 1. 安装依赖

```bash
# 进入目录
cd Glanstia_System

# 安装 gno SDK
npm install @gmickel/gno
# 或
bun add @gmickel/gno
```

### 2. 配置

```bash
# 复制配置模板
cp config.env.example ~/.openclaw/workspace/.env

# 编辑配置，填入你的 API Keys
nano ~/.openclaw/workspace/.env
```

### 3. 初始化工作目录

```bash
mkdir -p ~/.openclaw/workspace/{World,Styx,Hades,akasa,result}
```

### 4. 初始化 gno

```bash
# 确保已安装 bun
# 如果没有，安装: curl -fsSL https://bun.sh/install | bash

# 初始化 gno
export PATH="$HOME/.bun/bin:$PATH"
gno init ~/.openclaw/workspace --name workspace
gno index
```

### 5. 使用

```bash
# 测试 gno SDK
bun run gno/gno-sdk.js search "测试"

# 或使用 CLI
gno search "测试"
```

## 目录结构

```
Glanstia_System/
├── SKILL.md                    # 主文档
├── config.env.example          # 配置模板
├── gno/
│   └── gno-sdk.js             # gno SDK 封装
├── metaso-search/             # 秘塔搜索 skill
├── soul_maker/
│   ├── SKILL.md
│   └── prompts/               # Kerberos, Charon, Format
├── soul_guide/
│   └── SKILL.md
├── soul_summon/
│   └── SKILL.md
└── soul_nurture/
    ├── SKILL.md
    └── prompts/               # Elevate
```

## 工作流程

```
World/ (原始数据)
    ↓
Soul_Maker (创建人格)
    ↓
Styx/ (.soulmd 文件)
    ↓
Soul_Guide (吸收归档)
    ↓
Hades/ + souls.csv + gno索引
    ↓
Soul_Summon (召唤推理) ←→ akasa/ (知识库)
    ↓
Soul_Nurture (进化)
```

## 依赖

- Node.js 18+
- Bun runtime
- @gmickel/gno (npm install)
- API Keys (见 config.env.example)

## 文档

- [完整安装指南](./SKILL.md)
- [Soul_Maker](./soul_maker/SKILL.md)
- [Soul_Guide](./soul_guide/SKILL.md)
- [Soul_Summon](./soul_summon/SKILL.md)
- [Soul_Nurture](./soul_nurture/SKILL.md)

## 版本

- v0.1.2 - 完整打包版本
- 更新日期: 2026-03-13

# Soul_Guide - 灵魂导师

## 描述
负责吸收新灵魂（.soulmd）进入系统。提取标签、归档文件并建立索引。

## 流程

1. **扫描/接收**: 检查 `/workspace/Styx/` 目录下的 `.soulmd` 文件。
2. **提取标签**: 读取 `.soulmd` 内容，提取不超过 7 个核心关键词（Tags）。
3. **记录元数据**: 将 `文件名,标签1,标签2,...` 追加写入 `/workspace/souls.csv`。
4. **归档**: 将处理完的 `.soulmd` 移动到 `/workspace/Hades/`。
5. **建立索引**: 使用 gno 对 `Hades` 目录下的新文件和 `souls.csv` 更新索引（集合名: `souls`）。

## 工作目录

- 入口: `/workspace/Styx/`
- 归档: `/workspace/Hades/`
- 索引文件: `/workspace/souls.csv`

## 执行命令

### 1. 扫描 .soulmd 文件
```bash
ls /workspace/Styx/*.soulmd
```

### 2. 提取标签
读取 .soulmd 内容，从"核心标签"部分提取关键词。

### 3. 记录元数据
```bash
echo "文件名,标签1,标签2,标签3,标签4,标签5,标签6,标签7" >> /workspace/souls.csv
```

### 4. 移动归档
```bash
mv /workspace/Styx/xxx.soulmd /workspace/Hades/
```

### 5. 建立索引
```bash
# 使用 gno SDK
bun run gno-sdk.js index

# 或使用 CLI
gno index
```

## 输出

- `/workspace/souls.csv` - 人格索引
- `/workspace/Hades/*.soulmd` - 归档的人格文件
- gno 索引 (集合: souls)

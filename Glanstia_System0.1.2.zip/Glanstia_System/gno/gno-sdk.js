#!/usr/bin/env bun

/**
 * Gno SDK 封装 - 为 Glanstia 提供统一接口
 * 
 * 使用方式: 
 *   bun run gno-sdk.js search "query" [limit]
 *   bun run gno-sdk.js index
 *   bun run gno-sdk.js list
 * 
 * 首次使用前需要:
 *   1. npm install @gmickel/gno
 *   2. gno init ~/.openclaw/workspace --name workspace
 *   3. gno index
 */

import { createGnoClient, createDefaultConfig } from "@gmickel/gno";

const args = process.argv.slice(2);
const command = args[0];

// 工作目录 - 兼容不同环境
const WORKSPACE = process.env.WORKSPACE || 
  (process.env.HOME ? `${process.env.HOME}/.openclaw/workspace` : "/root/.openclaw/workspace");

let client = null;

async function getClient() {
  if (!client) {
    const config = createDefaultConfig();
    config.collections = [
      {
        name: "workspace",
        path: WORKSPACE,
        pattern: "**/*",
        include: [],
        exclude: [".git", "node_modules", ".venv", ".idea", "dist", "build", "__pycache__", ".DS_Store", "Thumbs.db"]
      }
    ];
    
    // 尝试使用现有 gno 配置
    const configPath = `${process.env.HOME || "/root"}/.config/gno/index.yml`;
    try {
      const fs = require('fs');
      if (fs.existsSync(configPath)) {
        config.configPath = configPath;
      }
    } catch (e) {}
    
    client = await createGnoClient({
      config,
      dbPath: `${process.env.HOME || "/root"}/.local/share/gno/index-default.sqlite`
    });
  }
  return client;
}

async function search(query, options = {}) {
  const c = await getClient();
  const results = await c.search(query, options);
  return results;
}

async function vsearch(query, options = {}) {
  const c = await getClient();
  const results = await c.vsearch(query, options);
  return results;
}

async function query(query, options = {}) {
  const c = await getClient();
  const results = await c.query(query, options);
  return results;
}

async function ask(query, options = {}) {
  const c = await getClient();
  const results = await c.ask(query, options);
  return results;
}

async function list() {
  const c = await getClient();
  const results = await c.list();
  return results;
}

async function get(uri) {
  const c = await getClient();
  const doc = await c.get(uri);
  return doc;
}

async function index(options = {}) {
  const c = await getClient();
  await c.index(options);
}

async function close() {
  if (client) {
    await client.close();
    client = null;
  }
}

// 主命令处理
(async () => {
  try {
    let result;
    
    switch (command) {
      case "search": {
        const q = args[1] || "";
        const n = parseInt(args[2]) || 5;
        result = await search(q, { limit: n });
        break;
      }
      
      case "vsearch": {
        const q = args[1] || "";
        const n = parseInt(args[2]) || 5;
        result = await vsearch(q, { limit: n });
        break;
      }
      
      case "query": {
        const q = args[1] || "";
        const n = parseInt(args[2]) || 5;
        result = await query(q, { limit: n });
        break;
      }
      
      case "ask": {
        const q = args[1] || "";
        result = await ask(q);
        break;
      }
      
      case "list": {
        result = await list();
        break;
      }
      
      case "get": {
        const uri = args[1];
        if (!uri) throw new Error("需要 URI 参数");
        result = await get(uri);
        break;
      }
      
      case "index": {
        await index();
        result = { success: true, message: "索引更新完成" };
        break;
      }
      
      default:
        console.error(`未知命令: ${command}`);
        console.error("可用命令: search, vsearch, query, ask, list, get, index");
        console.error("示例:");
        console.error("  bun run gno-sdk.js search \"关键词\"");
        console.error("  bun run gno-sdk.js search \"关键词\" 10");
        console.error("  bun run gno-sdk.js index");
        process.exit(1);
    }
    
    console.log(JSON.stringify(result, null, 2));
  } catch (error) {
    console.error(JSON.stringify({ error: error.message }));
    process.exit(1);
  } finally {
    await close();
  }
})();
